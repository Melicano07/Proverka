﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WS2021
{
    public partial class FRealtors : Form
    {
        public FRealtors()
        {
            InitializeComponent();
        }

        private void FRealtors_FormClosed(object sender, FormClosedEventArgs e)
        {
            Fmenu fmenu = new Fmenu();
            fmenu.Show();
        }

        private void FRealtors_Load(object sender, EventArgs e)
        {
            using (WS2021Entitie ws = new WS2021Entitie())
            {
               var риэлторы = ws.Риэлторы.Select(p => new
                {
                    Id = p.Id,
                    Фамилия = p.FirstName,
                    Имя = p.MiddleName,
                    Отчество = p.LastName,
                    Доля_от_комиссии = p.DealShare,
                }).ToList();

                dataGridView1.DataSource = риэлторы;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
              try
               {
                    Random numer = new Random();
                    using (WS2021Entitie ws = new WS2021Entitie())
                    {
                        Риэлторы риэлторы1 = new Риэлторы
                        {
                            Id = Convert.ToInt32(textBox5.Text),
                            FirstName = textBox1.Text,
                            MiddleName = textBox3.Text,
                            LastName = textBox2.Text,
                            DealShare = Convert.ToInt32(textBox4.Text)
                        };
                        ws.Риэлторы.Add(риэлторы1);
                        ws.SaveChanges();

                        var риэлторы = ws.Риэлторы.Select(p => new
                        {
                            Id = p.Id,
                            Фамилия = p.FirstName,
                            Имя = p.MiddleName,
                            Отчество = p.LastName,
                            Доля_от_комиссии = p.DealShare,
                        }).ToList();

                        dataGridView1.DataSource = риэлторы;

                    }
                }
                catch
                {
                    MessageBox.Show("Номер риелтора занят");
                }
            }
            else
            {
                MessageBox.Show("Не введено ФИО ");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var row = e.RowIndex;
            string a = dataGridView1[0, row].Value.ToString();
            int numa = Convert.ToInt32(a);
            numers.ind = numa;
            using (WS2021Entitie ws = new WS2021Entitie())
            {
                var del = ws.Риэлторы.Where(p => p.Id == numers.ind).FirstOrDefault();

                textBox5.Text = Convert.ToString(del.Id);
                textBox1.Text = del.FirstName;
                textBox3.Text = del.MiddleName;
                textBox2.Text = del.LastName;
                textBox4.Text = Convert.ToString(del.DealShare);

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (WS2021Entitie ws = new WS2021Entitie())
                {
                    var del = ws.Риэлторы.Where(p => p.Id == numers.ind).FirstOrDefault();
                    ws.Риэлторы.Remove(del);
                    ws.SaveChanges();


                    var риэлторы = ws.Риэлторы.Select(p => new
                    {
                        Id = p.Id,
                        Фамилия = p.FirstName,
                        Имя = p.MiddleName,
                        Отчество = p.LastName,
                        Доля_от_комиссии = p.DealShare,
                    }).ToList();

                    dataGridView1.DataSource = риэлторы;
                }
            }
            catch { MessageBox.Show("Не взможно удалить риэлтора"); }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox5.Text != "")
                {
                    using (WS2021Entitie ws = new WS2021Entitie())
                    {
                        var del = ws.Риэлторы.Where(p => p.Id == numers.ind).FirstOrDefault();
                        if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && Convert.ToInt32(textBox4.Text) < 101)
                        {
                            del.Id = Convert.ToInt32(textBox5.Text);
                            del.FirstName = textBox1.Text;
                            del.MiddleName = textBox3.Text;
                            del.LastName = textBox2.Text;
                            del.DealShare = Convert.ToInt32(textBox4.Text);
                            ws.SaveChanges();
                   

                        var риэлторы = ws.Риэлторы.Select(p => new
                        {
                            Id = p.Id,
                            Фамилия = p.FirstName,
                            Имя = p.MiddleName,
                            Отчество = p.LastName,
                            Доля_от_комиссии = p.DealShare,
                        }).ToList();

                        dataGridView1.DataSource = риэлторы;

                            textBox1.Text = "";
                            textBox2.Text = "";
                            textBox3.Text = "";
                            textBox4.Text = "";
                            textBox5.Text = "";
                        }
                        else { MessageBox.Show("Не заполнено ФИО или введён не верно введена доля от комиссии!"); }
                    }
                }
                else
                { MessageBox.Show("Не выбраны данные для изменения"); }

      
            }
            catch { MessageBox.Show("Нельзя поменять id!"); }
        }
    }
}
