﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WS2021
{
    public partial class FHouse : Form
    {
        public FHouse()
        {
            InitializeComponent();
        }

        private void FHouse_FormClosed(object sender, FormClosedEventArgs e)
        {
            Fmenu fmenu = new Fmenu();
            fmenu.Show();
        }

        private void FHouse_Load(object sender, EventArgs e)
        {
            using (WS2021Entitie ws = new WS2021Entitie())
            {
                var kvar = ws.Дома.Select(p => new
                {
                    Адрес = p.Адрес_Город + ", ул." + p.Адрес_Улица + ", д. " + p.Адркс_Дом + ", кв. " + p.Адрес_Квартира,
                    Координаты = p.Координаты_Широта + " " + p.Координаты_Долгота,
                    Этажность_дома = p.Количество_Этажей,
                    Количество_Комнат = p.Количество_Комнат,
                    Площадь = p.Площадь,
                }).ToList();
                dataGridView1.DataSource = kvar;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Random random = new Random();

                using (WS2021Entitie ws = new WS2021Entitie())
                {
                    Дома дома = new Дома()
                    {
                        Id = random.Next(1000),
                        Адрес_Город = textBox1.Text,
                        Адрес_Улица = textBox2.Text,
                        Адркс_Дом = Convert.ToInt32(textBox3.Text),
                        Адрес_Квартира = Convert.ToInt32(textBox4.Text),
                        Координаты_Долгота = Convert.ToInt32(textBox6.Text),
                        Координаты_Широта = Convert.ToInt32(textBox5.Text),
                        Количество_Комнат = Convert.ToInt32(textBox7.Text),
                        Количество_Этажей = Convert.ToInt32(textBox9.Text),
                        Площадь = Convert.ToInt32(textBox8.Text),
                    };
                    ws.Дома.Add(дома);
                    ws.SaveChanges();

                    using (WS2021Entitie ws1 = new WS2021Entitie())
                    {
                        var kvar = ws.Дома.Select(p => new
                        {
                            Адрес = p.Адрес_Город + ", ул." + p.Адрес_Улица + ", д. " + p.Адркс_Дом + ", кв. " + p.Адрес_Квартира,
                            Координаты = p.Координаты_Широта + ", " + p.Координаты_Долгота,
                            Этажность_дома = p.Количество_Этажей,
                            Количество_Комнат = p.Количество_Комнат,
                            Площадь = p.Площадь,
                        }).ToList();
                        dataGridView1.DataSource = kvar;
                    }
                }
            }
            catch { MessageBox.Show("Введены не верные данные"); }
        }
    }
}
