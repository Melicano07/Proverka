﻿namespace WS2021
{
    partial class FPredlojenia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.клиентыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1 = new WS2021.DataSet1();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.риэлторыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.клиентыTableAdapter = new WS2021.DataSet1TableAdapters.КлиентыTableAdapter();
            this.риэлторыTableAdapter = new WS2021.DataSet1TableAdapters.РиэлторыTableAdapter();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.CBHomes = new System.Windows.Forms.ComboBox();
            this.домаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.wS2021DataSet = new WS2021.WS2021DataSet();
            this.CBZemli = new System.Windows.Forms.ComboBox();
            this.землиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.CBKvartirs = new System.Windows.Forms.ComboBox();
            this.квартирыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.домаTableAdapter = new WS2021.WS2021DataSetTableAdapters.ДомаTableAdapter();
            this.землиTableAdapter = new WS2021.WS2021DataSetTableAdapters.ЗемлиTableAdapter();
            this.квартирыTableAdapter = new WS2021.WS2021DataSetTableAdapters.КвартирыTableAdapter();
            this.button2 = new System.Windows.Forms.Button();
            this.риэлторыBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.риэлторыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.домаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wS2021DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.землиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.квартирыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.риэлторыBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(776, 241);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(662, 259);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(126, 42);
            this.button1.TabIndex = 1;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(12, 288);
            this.textBox1.MaxLength = 10;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(161, 26);
            this.textBox1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 265);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Цена";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(12, 317);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Id Клиента";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(12, 369);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Id Агента";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.клиентыBindingSource;
            this.comboBox1.DisplayMember = "MiddleName";
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(12, 340);
            this.comboBox1.MaxLength = 10;
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(515, 28);
            this.comboBox1.TabIndex = 8;
            this.comboBox1.ValueMember = "Id";
            this.comboBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox1_KeyPress);
            // 
            // клиентыBindingSource
            // 
            this.клиентыBindingSource.DataMember = "Клиенты";
            this.клиентыBindingSource.DataSource = this.dataSet1;
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox2
            // 
            this.comboBox2.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.риэлторыBindingSource1, "Id", true));
            this.comboBox2.DataSource = this.риэлторыBindingSource;
            this.comboBox2.DisplayMember = "MiddleName";
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(12, 392);
            this.comboBox2.MaxLength = 10;
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(515, 28);
            this.comboBox2.TabIndex = 9;
            this.comboBox2.ValueMember = "Id";
            this.comboBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox2_KeyPress);
            // 
            // риэлторыBindingSource
            // 
            this.риэлторыBindingSource.DataMember = "Риэлторы";
            this.риэлторыBindingSource.DataSource = this.dataSet1;
            // 
            // клиентыTableAdapter
            // 
            this.клиентыTableAdapter.ClearBeforeFill = true;
            // 
            // риэлторыTableAdapter
            // 
            this.риэлторыTableAdapter.ClearBeforeFill = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(179, 265);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(153, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "Тип недвижимости";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(362, 265);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "Недвижимость";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // comboBox3
            // 
            this.comboBox3.DisplayMember = "Id";
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Квартиры",
            "Дома",
            "Земли"});
            this.comboBox3.Location = new System.Drawing.Point(179, 288);
            this.comboBox3.MaxLength = 10;
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(161, 28);
            this.comboBox3.TabIndex = 8;
            this.comboBox3.Text = "Квартиры";
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            this.comboBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.comboBox3_KeyPress);
            // 
            // CBHomes
            // 
            this.CBHomes.DataSource = this.домаBindingSource;
            this.CBHomes.DisplayMember = "Id";
            this.CBHomes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CBHomes.FormattingEnabled = true;
            this.CBHomes.Location = new System.Drawing.Point(366, 286);
            this.CBHomes.Name = "CBHomes";
            this.CBHomes.Size = new System.Drawing.Size(161, 28);
            this.CBHomes.TabIndex = 9;
            this.CBHomes.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // домаBindingSource
            // 
            this.домаBindingSource.DataMember = "Дома";
            this.домаBindingSource.DataSource = this.wS2021DataSet;
            // 
            // wS2021DataSet
            // 
            this.wS2021DataSet.DataSetName = "WS2021DataSet";
            this.wS2021DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // CBZemli
            // 
            this.CBZemli.DataSource = this.землиBindingSource;
            this.CBZemli.DisplayMember = "Id";
            this.CBZemli.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CBZemli.FormattingEnabled = true;
            this.CBZemli.Location = new System.Drawing.Point(366, 286);
            this.CBZemli.Name = "CBZemli";
            this.CBZemli.Size = new System.Drawing.Size(161, 28);
            this.CBZemli.TabIndex = 9;
            this.CBZemli.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // землиBindingSource
            // 
            this.землиBindingSource.DataMember = "Земли";
            this.землиBindingSource.DataSource = this.wS2021DataSet;
            // 
            // CBKvartirs
            // 
            this.CBKvartirs.DataSource = this.квартирыBindingSource;
            this.CBKvartirs.DisplayMember = "Id";
            this.CBKvartirs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CBKvartirs.FormattingEnabled = true;
            this.CBKvartirs.Location = new System.Drawing.Point(366, 286);
            this.CBKvartirs.MaxLength = 10;
            this.CBKvartirs.Name = "CBKvartirs";
            this.CBKvartirs.Size = new System.Drawing.Size(161, 28);
            this.CBKvartirs.TabIndex = 9;
            this.CBKvartirs.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            this.CBKvartirs.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CBKvartirs_KeyPress);
            // 
            // квартирыBindingSource
            // 
            this.квартирыBindingSource.DataMember = "Квартиры";
            this.квартирыBindingSource.DataSource = this.wS2021DataSet;
            // 
            // домаTableAdapter
            // 
            this.домаTableAdapter.ClearBeforeFill = true;
            // 
            // землиTableAdapter
            // 
            this.землиTableAdapter.ClearBeforeFill = true;
            // 
            // квартирыTableAdapter
            // 
            this.квартирыTableAdapter.ClearBeforeFill = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(662, 307);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(126, 42);
            this.button2.TabIndex = 1;
            this.button2.Text = "Удалить";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // риэлторыBindingSource1
            // 
            this.риэлторыBindingSource1.DataMember = "Риэлторы";
            this.риэлторыBindingSource1.DataSource = this.dataSet1;
            // 
            // FPredlojenia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 450);
            this.Controls.Add(this.CBKvartirs);
            this.Controls.Add(this.CBZemli);
            this.Controls.Add(this.CBHomes);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FPredlojenia";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Предложения";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FPredlojenia_FormClosed);
            this.Load += new System.EventHandler(this.FPredlojenia_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.риэлторыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.домаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wS2021DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.землиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.квартирыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.риэлторыBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private DataSet1 dataSet1;
        private System.Windows.Forms.BindingSource клиентыBindingSource;
        private DataSet1TableAdapters.КлиентыTableAdapter клиентыTableAdapter;
        private System.Windows.Forms.BindingSource риэлторыBindingSource;
        private DataSet1TableAdapters.РиэлторыTableAdapter риэлторыTableAdapter;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox CBHomes;
        private System.Windows.Forms.ComboBox CBZemli;
        private System.Windows.Forms.ComboBox CBKvartirs;
        private WS2021DataSet wS2021DataSet;
        private System.Windows.Forms.BindingSource домаBindingSource;
        private WS2021DataSetTableAdapters.ДомаTableAdapter домаTableAdapter;
        private System.Windows.Forms.BindingSource землиBindingSource;
        private WS2021DataSetTableAdapters.ЗемлиTableAdapter землиTableAdapter;
        private System.Windows.Forms.BindingSource квартирыBindingSource;
        private WS2021DataSetTableAdapters.КвартирыTableAdapter квартирыTableAdapter;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.BindingSource риэлторыBindingSource1;
    }
}