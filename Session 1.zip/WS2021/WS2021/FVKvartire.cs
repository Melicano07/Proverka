﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WS2021
{
    public partial class FVKvartire : Form
    {
        public FVKvartire()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
        
        }

        private void FVKvartire_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.dataSet1.Клиенты);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.Риэлторы". При необходимости она может быть перемещена или удалена.
            this.риэлторыTableAdapter.Fill(this.dataSet1.Риэлторы);
            using (WS2021Entitie ws = new WS2021Entitie())
            {
                var kv = ws.Потребность_В_Квартире.Select(p => new
                {
                    Адрес_Город = p.Адрес_Город,
                    Адрес_Улица = p.Адрес_Улица,
                    Адрес_Дом = p.Адрес_Дом,
                    Адрес_Квартира = p.Адрес_Квартира,
                    Мин_Цена = p.Мин_Цена,
                    Макс_Цена = p.Макс_Цена,
                    Агент = p.Риэлторы.FirstName + " " +  p.Риэлторы.MiddleName + " " +  p.Риэлторы.LastName,
                    Клиент = p.Клиенты.FirstName + " " + p.Клиенты.MiddleName + " " + p.Клиенты.LastName,
                    Мин_Площадь = p.Мин_Площадь,
                    Макс_Площадь = p.Макс_Площадь,
                    Мин_Комнат = p.Мин_Комнат,
                    Макс_Комнат = p.Макс_Комнат,
                    Мин_Этажей = p.Мин_Этажей,
                    Макс_Этажей = p.Макс_Этажей
                }).ToList();
                dataGridView1.DataSource = kv;
            }
        }

        private void FVKvartire_FormClosed(object sender, FormClosedEventArgs e)
        {
            FPotrbnosti fPotrbnosti = new FPotrbnosti();
            fPotrbnosti.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                Random random = new Random();
                using (WS2021Entitie ws = new WS2021Entitie())
                {
                    Потребность_В_Квартире VK = new Потребность_В_Квартире()
                    {
                        Id = random.Next(1000),
                        IDАгента = Convert.ToInt32(comboBox1.Text),
                        IDКлиента = Convert.ToInt32(comboBox2.Text),
                        Адрес_Город = textBox1.Text,
                        Адрес_Улица = textBox2.Text,
                        Адрес_Дом = Convert.ToInt32(textBox4.Text),
                        Адрес_Квартира = Convert.ToInt32(textBox3.Text),
                    
                        Макс_Цена = Convert.ToInt32(textBox7.Text),
                        Макс_Этажей = Convert.ToInt32(textBox5.Text),
                        Мин_Комнат = Convert.ToInt32(textBox12.Text),
                        Мин_Площадь = Convert.ToInt32(textBox10.Text),
                        Мин_Цена = Convert.ToInt32(textBox8.Text),
                        Мин_Этажей = Convert.ToInt32(textBox6.Text),
                    };
                    if (textBox12.Text == "") { VK.Мин_Комнат = null; }
                        ws.Потребность_В_Квартире.Add(VK);
                    ws.SaveChanges();


                    var kv = ws.Потребность_В_Квартире.Select(p => new
                    {
                        Адрес_Город = p.Адрес_Город,
                        Адрес_Улица = p.Адрес_Улица,
                        Адрес_Дом = p.Адрес_Дом,
                        Адрес_Квартира = p.Адрес_Квартира,
                        Мин_Цена = p.Мин_Цена,
                        Макс_Цена = p.Макс_Цена,
                        Агент = p.Риэлторы.FirstName + " " + p.Риэлторы.MiddleName + " " + p.Риэлторы.LastName,
                        Клиент = p.Клиенты.FirstName + " " + p.Клиенты.MiddleName + " " + p.Клиенты.LastName,
                        Мин_Площадь = p.Мин_Площадь,
                        Макс_Площадь = p.Макс_Площадь,
                        Мин_Комнат = p.Мин_Комнат,
                        Макс_Комнат = p.Макс_Комнат,
                        Мин_Этажей = p.Мин_Этажей,
                        Макс_Этажей = p.Макс_Этажей
                    }).ToList();
                    dataGridView1.DataSource = kv;
                }
            }
            catch { }
        }
    }
}
