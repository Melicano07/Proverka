﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WS2021
{
    public partial class FKlients : Form
    {
        public FKlients()
        {
            InitializeComponent();
        }

        private void FKlients_FormClosed(object sender, FormClosedEventArgs e)
        {
            Fmenu fmenu = new Fmenu();
            fmenu.Show();
        }

        private void FKlients_Load(object sender, EventArgs e)
        {
            using (WS2021Entitie ws = new WS2021Entitie())
            {
                var клиенты = ws.Клиенты.Select(p => new
                {
                    Id = p.Id,
                    Фамилия = p.FirstName,
                    Имя = p.MiddleName,
                    Отчество = p.LastName,
                    Номер_Телефона = p.Phone,
                    Эл_Почта = p.Email,
                }).ToList();

                dataGridView1.DataSource = клиенты;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox4.Text != "" || textBox5.Text != "")
            {
                try
                {
                    using (WS2021Entitie ws = new WS2021Entitie())
                    {
                        Клиенты клиенты1 = new Клиенты
                        {
                            Id = Convert.ToInt32(textBox6.Text),
                            FirstName = textBox1.Text,
                            MiddleName = textBox3.Text,
                            LastName = textBox2.Text,
                            Phone = textBox4.Text,
                            Email = textBox5.Text,
                        };
                        ws.Клиенты.Add(клиенты1);
                        ws.SaveChanges();

                        var клиенты = ws.Клиенты.Select(p => new
                        {
                            Id = p.Id,
                            Фамилия = p.FirstName,
                            Имя = p.MiddleName,
                            Отчество = p.LastName,
                            Номер_Телефона = p.Phone,
                            Эл_Почта = p.Email,
                        }).ToList();

                        dataGridView1.DataSource = клиенты;
                    }
                }
                catch
                {
                    MessageBox.Show("Номер клиента занят");
                }
            }
            else {
               MessageBox.Show("Введите эл. почту или номер телефона");
                 };

        }

        private void button2_Click(object sender, EventArgs e)
        {

            using (WS2021Entitie ws = new WS2021Entitie())
            {
                try
                {
                    var del = ws.Клиенты.Where(p => p.Id == numers.ind).FirstOrDefault();
                    ws.Клиенты.Remove(del);
                    ws.SaveChanges();

                    var клиенты = ws.Клиенты.Select(p => new
                    {
                        Id = p.Id,
                        Фамилия = p.FirstName,
                        Имя = p.MiddleName,
                        Отчество = p.LastName,
                        Номер_Телефона = p.Phone,
                        Эл_Почта = p.Email,
                    }).ToList();

                    dataGridView1.DataSource = клиенты;
                }
                catch { MessageBox.Show("Невозможно удалить клиента"); }
             }
            



            using (WS2021Entitie ws = new WS2021Entitie())
            {
                var deletsrt = ws.Клиенты.FirstOrDefault();
            };
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                var row = e.RowIndex;
                string a = dataGridView1[0, row].Value.ToString();
                numers.ind = Convert.ToInt32(a);
                using (WS2021Entitie ws = new WS2021Entitie())
                {
                    var del = ws.Клиенты.Where(p => p.Id == numers.ind).FirstOrDefault();
                    textBox6.Text = Convert.ToString(del.Id);
                    textBox1.Text = del.FirstName;
                    textBox3.Text = del.MiddleName;
                    textBox2.Text = del.LastName;
                    textBox4.Text = del.Phone;
                    textBox5.Text = del.Email;
                }
            }
            catch { }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox6.Text != "")
                {
                    using (WS2021Entitie ws = new WS2021Entitie())
                    {
                        var del = ws.Клиенты.Where(p => p.Id == numers.ind).FirstOrDefault();

                        if (textBox4.Text != "" || textBox5.Text != "")
                        {
                            del.Id = Convert.ToInt32(textBox6.Text);
                            del.FirstName = textBox1.Text;
                            del.MiddleName = textBox3.Text;
                            del.LastName = textBox2.Text;
                            del.Phone = textBox4.Text;
                            del.Email = textBox5.Text;


                        ws.SaveChanges();

                        var клиенты = ws.Клиенты.Select(p => new
                        {
                            Id = p.Id,
                            Фамилия = p.FirstName,
                            Имя = p.MiddleName,
                            Отчество = p.LastName,
                            Номер_Телефона = p.Phone,
                            Эл_Почта = p.Email,
                        }).ToList();

                        dataGridView1.DataSource = клиенты;
                            textBox1.Text = "";
                            textBox2.Text = "";
                            textBox3.Text = "";
                            textBox4.Text = "";
                            textBox5.Text = "";
                            textBox6.Text = "";
                        }
                        else { MessageBox.Show("Введите номер телефона или эл. почту"); }
                    }
                }
                else
                { MessageBox.Show("Не выбраны данные для изменения"); }

            }
            catch { MessageBox.Show("Нельзя поменять id!"); }
        }
    }
}

