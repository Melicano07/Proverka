﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WS2021
{
    public partial class Fmenu : Form
    {
        public Fmenu()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FKlients fKlients = new FKlients();
            fKlients.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FRealtors fRealtors = new FRealtors();
            fRealtors.Show();
            Hide();
        }

        private void Fmenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FNedvij fNedvij = new FNedvij();
            fNedvij.Show();
            Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FPotrbnosti fPotrbnosti = new FPotrbnosti();
            fPotrbnosti.Show();
            Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FPredlojenia fPredlojenia = new FPredlojenia();
            fPredlojenia.Show();
            Hide();
        }
    }
}
