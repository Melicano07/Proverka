﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WS2021
{
    public partial class FZemli : Form
    {
        public FZemli()
        {
            InitializeComponent();
        }

        private void FZemli_FormClosed(object sender, FormClosedEventArgs e)
        {
            Fmenu fmenu = new Fmenu();
            fmenu.Show();
        }

        private void FZemli_Load(object sender, EventArgs e)
        {
            using (WS2021Entitie ws = new WS2021Entitie())
            {
                var kvar = ws.Земли.Select(p => new
                {
                    Адрес = p.Адрес_Город + ", Ул. " + p.Адресс_Улица + ", д. " + p.Адрес_Дом + ", кв. " + p.Адрес_Квартира,
                    Координаты = p.Координаты_Широта + ", " + p.Координаты_Долгота,
                    Площадь = p.Площадь,
                }).ToList();
                dataGridView1.DataSource = kvar;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Random random = new Random();
                using (WS2021Entitie ws1 = new WS2021Entitie())
                {
                    Земли земли = new Земли()
                    {
                        Id = random.Next(1000),
                        Адрес_Город = textBox1.Text,
                        Адресс_Улица = textBox2.Text,
                        Адрес_Дом = Convert.ToInt32(textBox3.Text),
                        Адрес_Квартира = Convert.ToInt32(textBox4.Text),
                        Координаты_Долгота = Convert.ToInt32(textBox6.Text),
                        Координаты_Широта = Convert.ToInt32(textBox5.Text),
                        Площадь = Convert.ToInt32(textBox8.Text),

                    };
                    ws1.Земли.Add(земли);
                    ws1.SaveChanges();

                    var kvar = ws1.Земли.Select(p => new
                    {
                        Адрес = p.Адрес_Город + ", Ул. " + p.Адресс_Улица + ", д. " + p.Адрес_Дом + ", кв. " + p.Адрес_Квартира,
                        Координаты = p.Координаты_Широта + ", " + p.Координаты_Долгота,
                        Площадь = p.Площадь,
                    }).ToList();
                    dataGridView1.DataSource = kvar;
                }
            }
            catch { MessageBox.Show("Введены не верные данные"); }
        
       
        }
    }
}

