﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WS2021
{
    public partial class FPredlojenia : Form
    {
        public FPredlojenia()
        {
            InitializeComponent();
        }

        private void FPredlojenia_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "wS2021DataSet.Квартиры". При необходимости она может быть перемещена или удалена.
            this.квартирыTableAdapter.Fill(this.wS2021DataSet.Квартиры);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "wS2021DataSet.Земли". При необходимости она может быть перемещена или удалена.
            this.землиTableAdapter.Fill(this.wS2021DataSet.Земли);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "wS2021DataSet.Дома". При необходимости она может быть перемещена или удалена.
            this.домаTableAdapter.Fill(this.wS2021DataSet.Дома);
            //TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.Риэлторы".При необходимости она может быть перемещена или удалена.


            using (WS2021Entitie ws = new WS2021Entitie())
            {
                var pred = ws.Предложения.Select(p => new
                {
                    id = p.Id,
                    Цена = p.Цена,
                  Агент = p.Риэлторы.FirstName + " " +  p.Риэлторы.MiddleName + " " + p.Риэлторы.LastName,
                  Клиент = p.Клиенты.FirstName + " " + p.Клиенты.MiddleName + " " + p.Клиенты.LastName,
                  idКвартиры = p.IDКвартиры,
                  idДома = p.IDДома,
                  IdЗемли = p.IDЗемли
                }).ToList();
                dataGridView1.DataSource = pred;
            }
            this.риэлторыTableAdapter.FillBy(this.dataSet1.Риэлторы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.FillBy1(this.dataSet1.Клиенты);

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.Text == "Квартиры")
            {
                CBHomes.Visible = false;
                CBKvartirs.Visible = true;
                CBZemli.Visible = false;
                button1.Enabled = true;
            }
            else if (comboBox3.Text == "Дома")
            {
                CBHomes.Visible = true;
                CBKvartirs.Visible = false;
                CBZemli.Visible = false;
                button1.Enabled = true;
            }
            else if (comboBox3.Text == "Земли")
            {
                CBHomes.Visible = false;
                CBKvartirs.Visible = false;
                CBZemli.Visible = true;
                button1.Enabled = true;
            }
            else
            {
                CBHomes.Visible = false;
                CBKvartirs.Visible = false;
                CBZemli.Visible = false;
                button1.Enabled = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                try
                {
                    Random random = new Random();
                    using (WS2021Entitie ws = new WS2021Entitie())
                    {
                        Предложения pred1 = new Предложения()
                        {
                            Id = random.Next(1000),
                            Цена = Convert.ToInt32(textBox1.Text),
                            IDАгента = Convert.ToInt32(comboBox2.SelectedValue),
                            IDКлиента = Convert.ToInt32(comboBox1.SelectedValue),
                        };
                        if (comboBox3.Text == "Квартиры")
                        {
                            pred1.IDКвартиры = Convert.ToInt32(CBKvartirs.Text);
                        }
                        else if (comboBox3.Text == "Дома")
                        {
                            pred1.IDДома = Convert.ToInt32(CBHomes.Text);
                        }
                        else if (comboBox3.Text == "Земли")
                        {
                            pred1.IDЗемли = Convert.ToInt32(CBZemli.Text);
                        }

                        ws.Предложения.Add(pred1);
                        ws.SaveChanges();

                        var pred = ws.Предложения.Select(p => new
                        {
                            id = p.Id,
                            Цена = p.Цена,
                            Агент = p.Риэлторы.FirstName + p.Риэлторы.MiddleName + p.Риэлторы.LastName,
                            Клиент = p.Клиенты.FirstName + p.Клиенты.MiddleName + p.Клиенты.LastName,
                            idКвартиры = p.IDКвартиры,
                            idДома = p.IDДома,
                            IdЗемли = p.IDЗемли
                        }).ToList();
                        dataGridView1.DataSource = pred;
                   }
                }
                catch { MessageBox.Show("Данные введены не верно"); }
            }
            else { MessageBox.Show("Напишите цену"); }
        }

        private void FPredlojenia_FormClosed(object sender, FormClosedEventArgs e)
        {
            Fmenu fmenu = new Fmenu();
            fmenu.Show();
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void comboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void comboBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void CBKvartirs_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (WS2021Entitie ws = new WS2021Entitie())
                {
                    var rem = ws.Предложения.Where(p => p.Id == numers.inda).FirstOrDefault();
                    ws.Предложения.Remove(rem);
                    ws.SaveChanges();



                    var pred = ws.Предложения.Select(p => new
                    {
                        id = p.Id,
                        Цена = p.Цена,
                        Агент = p.Риэлторы.FirstName + " " + p.Риэлторы.MiddleName + " " + p.Риэлторы.LastName,
                        Клиент = p.Клиенты.FirstName + " " + p.Клиенты.MiddleName + " " + p.Клиенты.LastName,
                        idКвартиры = p.IDКвартиры,
                        idДома = p.IDДома,
                        IdЗемли = p.IDЗемли
                    }).ToList();
                    dataGridView1.DataSource = pred;
                }
            }
            catch { }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try {
                var row = e.RowIndex;
                string a = dataGridView1[0, row].Value.ToString();
                int aint = Convert.ToInt32(a);
                numers.inda = aint;
            }
            catch { }
        }

        private void fillBy1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.клиентыTableAdapter.FillBy1(this.dataSet1.Клиенты);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy1ToolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                this.клиентыTableAdapter.FillBy1(this.dataSet1.Клиенты);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.риэлторыTableAdapter.FillBy(this.dataSet1.Риэлторы);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
    }

