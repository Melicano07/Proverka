﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WS2021
{
    public partial class FVHouse : Form
    {
        public FVHouse()
        {
            InitializeComponent();
        }

        private void FVHouse_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.dataSet1.Клиенты);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataSet1.Риэлторы". При необходимости она может быть перемещена или удалена.
            this.риэлторыTableAdapter.Fill(this.dataSet1.Риэлторы);
            using (WS2021Entitie ws = new WS2021Entitie())
            {
                var kv = ws.Потребность_в_доме.Select(p => new
                {
                    Адрес_Город = p.Адрес_Город,
                    Адрес_Улица = p.Адрес_Улица,
                    Адрес_Дом = p.Адрес_Дом,
                    Адрес_Квартира = p.Адрес_Квартира,
                    Мин_Цена = p.МинСтоимость,
                    Макс_Цена = p.МаксСтоимость,
                    Агент = p.Риэлторы.FirstName + " " + p.Риэлторы.MiddleName + " " + p.Риэлторы.LastName,
                    Клиент = p.Клиенты.FirstName + " " + p.Клиенты.MiddleName + " " + p.Клиенты.LastName,
                    Мин_Площадь = p.МинПлощадь,
                    Макс_Площадь = p.МаксПлощадь,
                    Мин_Комнат = p.МинКомнат,
                    Макс_Комнат = p.МинКомнат,
                    Мин_Этажей = p.МинЭтажей,
                    Макс_Этажей = p.МаксЭтажей
                }).ToList();
                dataGridView1.DataSource = kv;
            }
        }

        private void FVHouse_FormClosed(object sender, FormClosedEventArgs e)
        {
            FPotrbnosti fPotrbnosti = new FPotrbnosti();
            fPotrbnosti.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Random random = new Random();
                using (WS2021Entitie ws = new WS2021Entitie())
                {
                    Потребность_в_доме VH = new Потребность_в_доме()
                    {
                        Id = random.Next(1000),
                        IDАгента = Convert.ToInt32(comboBox1.Text),
                        IDКлиента = Convert.ToInt32(comboBox2.Text),
                        Адрес_Город = textBox1.Text,
                        Адрес_Улица = textBox2.Text,
                        Адрес_Дом = Convert.ToInt32(textBox4.Text),
                        Адрес_Квартира = Convert.ToInt32(textBox3.Text),
                        МаксКомнат = Convert.ToInt32(textBox11.Text),
                        МаксПлощадь = Convert.ToInt32(textBox9.Text),
                        МаксСтоимость = Convert.ToInt32(textBox7.Text),
                        МаксЭтажей = Convert.ToInt32(textBox5.Text),
                        МинКомнат = Convert.ToInt32(textBox12.Text),
                        МинПлощадь = Convert.ToInt32(textBox10.Text),
                        МинСтоимость = Convert.ToInt32(textBox8.Text),
                        МинЭтажей = Convert.ToInt32(textBox6.Text),
                    };
                    ws.Потребность_в_доме.Add(VH);
                    ws.SaveChanges();

                    var kv = ws.Потребность_в_доме.Select(p => new
                    {
                        Адрес_Город = p.Адрес_Город,
                        Адрес_Улица = p.Адрес_Улица,
                        Адрес_Дом = p.Адрес_Дом,
                        Адрес_Квартира = p.Адрес_Квартира,
                        Мин_Цена = p.МинСтоимость,
                        Макс_Цена = p.МаксСтоимость,
                        Агент = p.Риэлторы.FirstName + " " + p.Риэлторы.MiddleName + " " + p.Риэлторы.LastName,
                        Клиент = p.Клиенты.FirstName + " " + p.Клиенты.MiddleName + " " + p.Клиенты.LastName,
                        Мин_Площадь = p.МинПлощадь,
                        Макс_Площадь = p.МаксПлощадь,
                        Мин_Комнат = p.МинКомнат,
                        Макс_Комнат = p.МинКомнат,
                        Мин_Этажей = p.МинЭтажей,
                        Макс_Этажей = p.МаксЭтажей
                    }).ToList();
                    dataGridView1.DataSource = kv;
                }
            }
            catch { }
        }
    }
}
