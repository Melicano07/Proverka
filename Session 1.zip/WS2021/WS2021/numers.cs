﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WS2021
{
    class numers
    {
        public static int ind;
        public static int inda;
    }
}
